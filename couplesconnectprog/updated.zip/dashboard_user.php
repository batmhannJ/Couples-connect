<?php
require "includes/cc_header.php";
$header_name = '';
if($_SESSION['usertype'] == 'DSK'){
    $header_name = "DESK";
}else if($_SESSION['usertype'] == 'CNR'){
    $header_name = "COUNSELOR";
}else if($_SESSION['usertype'] == 'HED'){
    $header_name = "HEAD";
}else if($_SESSION['usertype'] == 'USR'){
    $header_name = "USER";
}


$select_db="SELECT * FROM mf_prog_users WHERE recid=?";
$stmt	= $link->prepare($select_db);
$stmt->execute(array($_SESSION['usr_recid']));
$row = $stmt->fetch();
$act_status = $row["act_status"];

?>

<style>
    .has_hover:hover{
        cursor:pointer;
        opacity:0.5;
    }
</style>

<div class="container-fluid">
        <div class='row bg-white' style="height:99px">
            <div class="col-3 pe-0 d-flex align-items-center">
                <img src="images/350 x 88.png" style='height:76px;width:auto;'>
            </div>

            <div class="col-3 offset-6" style="display:flex;flex-direction:row;justify-content:center;font-family:inter;font-size:21px;align-items:center"> 
                <div style="flex:1.6;text-align:right;margin-right:25px">
                    <a href="http://localhost/couplesconnectprog/dashboard_user.php" style='color:black;text-decoration:none' class='has_hover'>SERVICES</a>
                </div>

                <div style="flex:1.8;text-align:center;margin-right:10px">
                    <a style='color:black;text-decoration:none' class='has_hover' onclick="openFeedback()">FEEDBACK</a>
                </div>

                <div style="flex:0.3;text-align:center;padding-right:10px">
                    <a href="" style='color:black;text-decoration:none'>|</a>
                </div>

                <div style="flex:1;text-align:center;margin-right:20px">
                    <a style='color:black;text-decoration:none'><?php echo $header_name;?> </a>
                </div>

                <div style="flex:0.6;text-align:right;padding-right:145px">
                    <a href="http://localhost/couplesconnectprog/logout_cc.php" style='color:black;text-decoration:none' class='has_hover'>LOGOUT</a>
                </div>
            </div> 
        </div>
    </div>
    
    <form name='myforms' id="myforms" method="post" target="_self" style='height:100%'> 
        <table style="width:100%;height:calc(100% - 100px);	filter: drop-shadow(0px 4px 15px rgba(0, 0, 0, 0.25))">
            <tr>
                <td class="d-flex align-items-top mx-0 px-0">
                    <div class="d-flex" style="display:flex;flex-direction:row;width:200%">
                        <div style="width:50%;display:flex;justify-content:center;flex-direction:column;align-items:center">

                            <div style='width:80%;height:40%;background-color:white;border-radius:15px' class="mt-4">
                                <div class="pt-3" style='font-size:22px;font-family:inter;font-weight:700;text-align:center'>Status</div>
                                <div style='width:100%;display:flex;justify-content:center'>
                                    <img src="images/Rectangle 11934.png" style='width:80%;height:4px'>
                                </div>
                                <div>
                                    <?php   

                                    $book_now_disbaled = "";
                                    $req_now_disabled = "";
                                    if($act_status == "APR"){
                                        echo "<div class='text-center' style='font-family:inter;font-size:22px;font-weight:700;margin-top:20px'>";
                                            echo "<img src='images/Group.png'>";
                                            echo "<span style='margin-left:10px'>Requires Pre-Marriage Orientation</span>";
                                        echo "</div>";

                                        $req_now_disabled = "disabled";

                                    }else if($act_status == "PMO"){
                                        echo "<div class='text-center' style='font-family:inter;font-size:22px;font-weight:700;margin-top:20px'>";
                                            echo "<img src='images/Group.png'>";
                                            echo "<span style='margin-left:10px'>Waiting for Approval</span>";
                                        echo "</div>";

                                        // $book_now_disbaled = "disabled";
                                        $req_now_disabled = "disabled";
                                    }else if($act_status == "PMC"){
                                        echo "<div class='text-center' style='font-family:inter;font-size:22px;font-weight:700;margin-top:20px'>";
                                            echo "<img src='images/Group.png'>";
                                            echo "<span style='margin-left:10px'>Requires Pre-Marriage Counseling</span>";
                                        echo "</div>";

                                        $req_now_disabled = "disabled";
                                    }else if($act_status == "NCT"){
                                        echo "<div class='text-center' style='font-family:inter;font-size:22px;font-weight:700;margin-top:20px'>";
                                            echo "<img src='images/red_x.png' style='width:20px;height:20px;'>";
                                            echo "<span style='margin-left:10px'>Certification Declined</span>";
                                        echo "</div>";

                                        $book_now_disbaled = "disabled";
                                        $req_now_disabled = "disabled";
                                    }else if($act_status == "RVW"){
                                        echo "<div class='text-center' style='font-family:inter;font-size:22px;font-weight:700;margin-top:20px'>";
                                            echo "<img src='images/Group.png'>";
                                            echo "<span style='margin-left:10px'>Account application for review</span>";
                                        echo "</div>";

                                        $book_now_disbaled = "disabled";
                                        $req_now_disabled = "disabled";

                                    }else if($act_status == "DEC"){
                                        echo "<div class='text-center' style='font-family:inter;font-size:22px;font-weight:700;margin-top:20px'>";
                                            echo "<img src='images/red_x.png' style='width:20px;height:20px;'>";
                                            echo "<span style='margin-left:10px'>Account Declined</span>";
                                        echo "</div>";

                                        $book_now_disbaled = "disabled";
                                        $req_now_disabled = "disabled";
                                    }else if($act_status == "PCT"){
                                        echo "<div class='text-center' style='font-family:inter;font-size:22px;font-weight:700;margin-top:20px'>";
                                            echo "<img src='images/Group.png'>";
                                            echo "<span style='margin-left:10px'>Move on to Certification</span>";
                                        echo "</div>";

                                        $book_now_disbaled = "disabled";
                                    }


                                    ?>

                                </div>
                                
                            </div>

                            <div style='width:80%;height:40%;background-color:white;border-radius:15px' class="mt-4">
                                    <div class="pt-3" style='font-size:22px;font-family:inter;font-weight:700;text-align:center'>Appointment</div>
                                    <div style='width:100%;display:flex;justify-content:center'>
                                        <img src="images/Rectangle 11934.png" style='width:80%;height:4px'>
                                    </div>

                                    <div style='width:100%;display:flex;justify-content:center'>

                                        <?php

                                            if($act_status == "PMO"){

                                                $select_db2="SELECT ext_mf_meiform.date as 'mf_date', ext_mf_meiform.from_to as 'from_to'  FROM ext_mf_meiform LEFT JOIN pro_meiform ON ext_mf_meiform.usermeiformid = pro_meiform.usermeiformid  WHERE ext_mf_meiform.userid=? AND pro_meiform.status = 'PMO' LIMIT 1";
                                                $stmt2	= $link->prepare($select_db2);
                                                $stmt2->execute(array($_SESSION['usr_id']));
                                                $row2 = $stmt2->fetch();

                                                $from_to = $row2["from_to"];
                                                $date_formatted = date('F d, Y', strtotime($row2["mf_date"]));

                                                if(!empty($from_to) && !empty($date_formatted)){
                                                    echo "<div style='font-family:inter;font-size:22px;font-weight:700;margin-top:20px;display:flex;flex-direction:row'>";
                                                        echo "<img src='images/calendar_yellow.png' style='width:35px;height:35px;margin-top:15px'>";
                                                        echo "<div style='display:flex;flex-direction:column'>";
                                                            echo "<span style='margin-left:10px'>".$date_formatted."(".$from_to.")</span>";
                                                            echo "<span style='margin-left:10px;font-size:11px;color:#616161;font-weight:400'>Pre-Marriage Orientation</span>";
                                                        echo "</div>";
                                                        
                                                    echo "</div>";

                                                }



                                            }else if($act_status == "PMC"){

                                                $select_db2="SELECT ext_mf_meiform.date as 'mf_date', ext_mf_meiform.from_to as 'from_to'  FROM ext_mf_meiform RIGHT JOIN pro_meiform ON ext_mf_meiform.usermeiformid = pro_meiform.usermeiformid  WHERE ext_mf_meiform.userid=? AND pro_meiform.status = 'PMC' LIMIT 1";
                                                $stmt2	= $link->prepare($select_db2);
                                                $stmt2->execute(array($_SESSION['usr_id']));
                                                $row2 = $stmt2->fetch();

                                                $from_to = $row2["from_to"];
                                                $date_formatted = date('F d, Y', strtotime($row2["mf_date"]));

                                                if(!empty($from_to) && !empty($date_formatted)){
                                                    echo "<div style='font-family:inter;font-size:22px;font-weight:700;margin-top:20px;display:flex;flex-direction:row'>";
                                                        echo "<img src='images/calendar_yellow.png' style='width:35px;height:35px;margin-top:15px'>";
                                                        echo "<div style='display:flex;flex-direction:column'>";
                                                            echo "<span style='margin-left:10px'>".$date_formatted."(".$from_to.")</span>";
                                                            echo "<span style='margin-left:10px;font-size:11px;color:#616161;font-weight:400'>Pre-Marriage Counseling</span>";
                                                        echo "</div>";
                                                        
                                                    echo "</div>";

                                                    $book_now_disbaled = "";
                                                    $req_now_disabled = "disabled";
                                                }else{
                                                    $book_now_disbaled = "";
                                                    $req_now_disabled = "disabled";
                                                }
                                            }else{
                                                echo "<div class='text-center' style='font-family:inter;font-size:22px;font-weight:700;margin-top:20px'>";
                                                    echo "<span style='margin-left:10px'></span>";
                                                echo "</div>";

                                                            
                           
                                            }

                                        ?>
                                    </div>
                                <div>

                                </div>
                                
                            </div>
       

                        </div>
                        <div style="width:50%">
                           <img src="images/Intro.png" style='width:100%' alt="">
                        </div>
                    </div>
                </td>
            </tr>

            <tr>
                <td class="d-flex align-items-top mx-0 px-0">
                    <div class="container-fluid pt-2" style="width:100%">
                        <div class="row d-flex justify-content-center">
                            <div style='width:25%;display:flex;justify-content:center;flex-direction:column;align-items:center'>
                                    <div class='text-center' style='font-size:22px;font-family:inter;font-weight:700'>SERVICES OFFERED</div>
                                    <img style='display:block;width:80%' src="images/blue_line.png" alt="">
                            </div>
                        </div>

                        <div class="row pt-2">
                            <div class="col-6 d-flex justify-content-center">
                                <div style='width:80%;background-color:white;border-radius:15px' class="mt-2">
                                    <div class="pt-3 d-flex align-items-end justify-content-center" style='font-size:28px;font-family:inter;font-weight:800;text-align:center;height:60px;
                                            background-color:#385399;color:#FFFFFF;
                                            border-top-left-radius:15px;
                                            border-top-right-radius:15px'>
                                        <span style='filter: drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.63))'>BOOKING</span>
                                    </div>
                 
                                    <div>
                                        <div>
                                            <div class="col-12 text-center m-3" style='font-size:15px;font-family:inter;color:black;font-weight:800'>
                                            Pre-Marriage Orientation and Counseling (PMOC) Booking
                                            </div>

                                            <div class="col-12 text-center mx-3 mb-2 d-flex justify-content-center" style='font-size:14px;font-family:inter;color:black;font-weight:500' >
                                                <div style='width:70%'>Book your PMOC session now and invest in the well-being of your relationship. Start your married life with confidence, communication, and a deeper connection.</div>
                                            </div>

                                            <div class="d-flex justify-content-center mb-2">
                                                <button type="button" <?php echo $book_now_disbaled; ?> onclick="onBooking()" class="btn" style="background: rgb(35,64,142);background: linear-gradient(90deg, rgba(35,64,142,1) 35%, rgba(60,148,198,1) 100%);color:white;width:200px;height:36px;font-size:17px;font-family:inter;font-weight:700;border-radius:10px;filter: drop-shadow(0px 4px 11px rgba(0, 0, 0, 0.25))">
                                                    Book Now
                                                </button>
                                            </div>
                                        </div>

                                    </div>
                                    
                                </div>
                            </div>
                            
                            <div class="col-6 d-flex justify-content-center">
                                <div style='width:80%;background-color:white;border-radius:15px' class="mt-2">
                                    <div class="pt-3 d-flex align-items-end justify-content-center" style='font-size:28px;font-family:inter;font-weight:800;text-align:center;height:60px;
                                            background-color:#385399;color:#FFFFFF;
                                            border-top-left-radius:15px;
                                            border-top-right-radius:15px'>
                                        <span style='filter: drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.63))'>CERTIFICATION</span>
                                    </div>
                 
                                    <div>
                                        <div>
                                            <div class="col-12 text-center m-3" style='font-size:15px;font-family:inter;color:black;font-weight:800'>
                                            Pre-Marriage Orientation and Counseling (PMOC) Certificate
                                            </div>

                                            <div class="col-12 text-center mx-3 mb-2 d-flex justify-content-center" style='font-size:14px;font-family:inter;color:black;font-weight:500' >
                                                <div style='width:70%'>Celebrate your accomplishment and the journey to a fulfilling marriage by proudly displaying your PMOC certification.</div>
                                            </div>

                                            <div class="d-flex justify-content-center">
                                                <button type="button"  <?php echo $req_now_disabled; ?> onclick="onRequesting()" class="btn" style="background: rgb(35,64,142);background: linear-gradient(90deg, rgba(35,64,142,1) 35%, rgba(60,148,198,1) 100%);color:white;width:200px;height:36px;font-size:17px;font-family:inter;font-weight:700;border-radius:10px;filter: drop-shadow(0px 4px 11px rgba(0, 0, 0, 0.25))">
                                                    Request Now
                                                </button>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </td>
            </tr>

        
        </table>

        <div class="modal fade  xerror_modal" data-bs-backdrop="static" id="xerror_modal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Couples Connect Says:</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p class="error_msg">Modal body text goes here.</p>
                    </div>
     
                </div>
            </div>
        </div>

        <div class="modal fade modal_feedback" id="modal_feedback" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content" style='border-radius:25px'>
                <div class="modal-header">
                    <div class="modal-title">
                        <div style="color:black;font-family:inter;color:#252733;font-size:33px;font-weight:600">Feeback</div>
                        <div style="color:black;font-family:inter;color:#9B9B9B;font-size:21px;margin-top:-5px">Fill Up Form</div>
                    </div>
          
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body mx-3">

                    <label for="" style='font-size:21px;color:252733;font-weight:600;font-family:inter'>Subject:</label>
                    <input type="text" class='form-control' style='border-radius:5px;height:50px;border:1px solid black' placeholder='Enter your subject' name="feedback_subject" id="feedback_subject">


                    <label for="" style='font-size:21px;color:252733;font-weight:600;font-family:inter;margin-top:20px'>Feedback:</label>
                    <textarea class="form-control" name="feedback_remarks" id="feedback_remarks" cols="30" rows="7" style='border-radius:5px;border:1px solid black' placeholder='Enter remarks'></textarea>
                    <div style='display:flex;justify-content:center;padding-top:25px;padding-bottom:20px'>
                        <button type="button" onclick="ajaxSubmit()" class="btn" style=";background: linear-gradient(90deg, rgba(35,64,142,1) 35%, rgba(60,148,198,1) 100%);color:white;width:250px;height:45px;font-size:25px;font-family:inter;font-weight:700;border-radius:10px;filter: drop-shadow(0px 4px 11px rgba(0, 0, 0, 0.25))">Submit</button>
                    </div>
                    
                </div>
          
                </div>
            </div>
        </div>        

        <footer style='height:100px;background-color:#23408E' class='footer'>
            <div class="container-fluid"  style='height:100px'>

                <div class="row"  style='height:100px'>
                    <div class="col-4">
                        <div class="row ms-3"  style='height:100px'>
                            <div class="col-2 d-flex align-items-center">
                                <img src="images/op office logo.png" style="height:77px;width:auto">
                            </div>

                            <div class="col-10 d-flex align-items-center">
                                <div class="container" style='font-family:inter;color:white'>
                                    <div class="col-12" style='font-size:15px;font-weight:bold'>
                                        City Population Office of Cabuyao
                                    </div>

                                    <div class="col-12" style='font-size:9px'>
                                        Brgy Dos. Cabuyao Retail Plaza, Cabuyao, Philippines
                                    </div>

                                    <div class="col-12" style='font-size:9px'>
                                        cpocabuyao@gmail.com
                                    </div>

                                </div>
          
                            </div>
                        </div>       
                    </div>

                    <div class="col-8 d-flex align-items-center justify-content-end">
                        <div>
                            <img src="images/pajamas_question.png" style='width:63px;height:auto;'>
                        </div>   
                    </div>
                </div>

            </div>
        </footer>
        
    </form>

    <script>

        function openFeedback(){
            $("#modal_feedback").modal("show");
        }

        function ajaxSubmit(){

            var email_subject = $("#feedback_subject").val();
            var email_remarks = $("#feedback_remarks").val();


            jQuery.ajax({    
                data:{
                    email_subject:email_subject,
                    email_remarks:email_remarks
                },
                dataType:"json",
                type:"post",
                url:"dashboard_user_ajax.php", 
                success: function(xdata){
                    $("#modal_feedback").modal("hide");
                },
                error: function (request, status, error) {
                }

            })

        }

        function onBooking(){
            document.forms.myforms.method = "post";
            document.forms.myforms.target = "_self";
            document.forms.myforms.action = "booking.php";
            document.forms.myforms.submit();
        }

        function onRequesting(){
            document.forms.myforms.method = "post";
            document.forms.myforms.target = "_self";
            document.forms.myforms.action = "cc_usr_certification.php";
            document.forms.myforms.submit();
        }

        function validateEmail(input) {
            var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

            if (input.value.match(validRegex)) {
                return true;
            } else {
                return false;
            }

        }



    </script>



<?php 
require "includes/cc_footer.php";
?>


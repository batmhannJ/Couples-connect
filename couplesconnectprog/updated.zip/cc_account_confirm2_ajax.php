<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

session_start();
require_once('resources/db_init.php');
require_once('resources/lx2.pdodb.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

$chkusertype = $_SESSION["username"];
$ret=array();
$ret['status']= true;

require_once('resources/connect4.php');

$select_db="SELECT * FROM mf_prog_users WHERE recid=?";
$stmt	= $link->prepare($select_db);
$stmt->execute(array($_POST["ac_recid_hidden"]));
$rs = $stmt->fetch();
$useremail = $rs['username'];


$date_today = date('Y-m-d');
$date_today_desc = date('F d, Y', strtotime($date_today));

$arr_record_data = array();
$arr_record_data['act_status'] 	= $_POST['event_action'];
$arr_record_data['chk_by'] 	= $chkusertype;
$arr_record_data['date_requested'] 	= $date_today;
$arr_record_data['date_requested_desc'] 	= $date_today_desc;
PDO_UpdateRecord($link,"mf_prog_users",$arr_record_data,"recid = ?",array($_POST["ac_recid_hidden"]),false);  


if($_POST['event_action'] == "DEC"){
    $xemail_title = "Couples Connect User, Declined";
    $xemail_body = "Good Day!,".$useremail.". This is ".$chkusertype." from <b>Couples Connect</b> unfortunately, we have reviewed your approval and deemed that you do not further need counselling, Take Care!";
}else{
    $xemail_title = "Couples Connect User, Approved";
    $xemail_body = "Good Day!,".$useremail.". This is ".$chkusertype." from <b>Couples Connect</b>, your request for approval has been <b>approved</b>. Kindly Login to the website to proceed with the next step, Take Care!";
}

// EMAIL SEDING
$mail = new PHPMailer(true);
$mail->isSMTP();
$mail->Host='smtp.gmail.com';
$mail->SMTPAuth=true;
$mail->Username='lennardleework@gmail.com';
$mail->Password='dsfs xoai msta xgrh';
$mail->SMTPSecure='ssl';
$mail->Port=465;

$mail->setFrom('lennardleework@gmail.com');
$mail->addAddress($useremail);
$mail->isHTML(true);
$mail->Subject = $xemail_title;
$mail->Body = $xemail_body;
$mail->send();



header('Content-Type: application/json');
echo json_encode($ret);
?>
